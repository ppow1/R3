<!--
R3 CONTROLLED DOCUMENT
File: docs/architecture/R3A_AP3_STEWARD_ACCESS.md
Component: R3A-AP3-STEWARD-ACCESS
File Revision: 1.1.0
Created: 2026-11-07T21:37:42Z
Created By: Codex GPT-6
Purpose: Specify the AP3-M1 identity/session boundary, portal endpoints, authority delegation, and freshness behavior.
Execution Model: Architecture/contract record for the R3A-owned Steward identity and session boundary.
Observability: Versioned contracts, correlation IDs, structured log metadata, PostgreSQL append-only audit evidence.
Dependencies: AP0 PostgreSQL event ledger and CME Unix control protocol; Bitwarden/machine identity provider coordination in Issue #50.
Authority: Roadmap Baseline 1.0, AP3-M1 Issue #49, R3A-010 and R3A-013; exception None.
Changed: 2026-11-07T21:37:42Z | AP3-M1 | Codex GPT-6 | Record the implemented ingress identity/session and CME delegation contracts.
Changed: 2026-11-07T21:44:36Z | AP3-M1 | Codex GPT-6 | Specify signed factor references and index the responsive portal prototype.
Changed: 2026-11-07T21:48:11Z | AP3-M1 | Codex GPT-6 | Document the live CME health read and unavailable-state behavior.
Changed: 2026-11-07T21:53:47Z | AP3-M1 | Codex GPT-6 | Align secret resolution and machine-principal evidence with Issue #50's published API.
Changed: 2026-11-07T22:00:10Z | AP3-M1 | Codex GPT-6 | Define minimum database privileges and session factor metadata.
Changed: 2026-11-07T22:02:18Z | AP3-M1 | Codex GPT-6 | Document configurable database acquisition timeout and durable invalid-session/origin denials.
Changed: 2026-11-07T22:03:19Z | AP3-M1 | Codex GPT-6 | Specify mandatory Secure session cookies for configured remote transport.
Changed: 2026-11-07T23:53:17Z | AP3-M1/AP3-M2 | Codex GPT-6 | Record Bitwarden 1.1.0 compatibility, safe reason codes, and complete contract provenance.
Changed: 2026-11-07T23:53:17Z | AP3-M1/#51 | Codex GPT-6 | Document the shared Website principal dependency and coordinated prototype demonstration.
Changed: 2026-11-07T23:57:23Z | AP3-M1/#51 | Codex GPT-6 | Share one /api/v1 cookie with Website APIs and expose generic CME operation discovery.
Changed: 2026-11-09T16:32:39Z | R3A-AUTH-INDEPENDENCE-001 | Codex GPT-6 | Correct target authority boundary to R3A-owned identity and mark R3 portal adapter as legacy-only.
Supersedes: None.
Contracts: r3a.steward-identity.v1; r3a.steward-session.v1; r3a.steward-operation-result.v1; r3a.steward-access-status.v1.
Tests: tests/test_r3a_steward_access.py; live transport remains unconfigured.
History/Predecessor: New file; initial publication recorded in Git.
-->
# AP3-M1 Steward access prototype

## Assignment traceability

- Approved roadmap: Master Roadmap Baseline 1.0.
- Phase/milestone: AP3-M1.
- Requirements: R3A-010 and R3A-013.
- Authorized scope: Issue #49, secure Steward identity/session lifecycle, grant enforcement, portal operations, mobile-friendly same-origin routes, and explicit remote freshness/unavailability.
- Acceptance: authenticated authoritative read, CME-authorized operation, denied invalid access, session revocation, correlated durable audit; remote/mobile proof when an ingress is available.
- Approved exception: None.

## Existing authority boundaries

R3A must own its login and session authority and must remain operable when R3 login, account/session services, database, and website are unavailable. The current R3 account-session adapter is a legacy prototype dependency and is not acceptable for independent R3A deployment. The AP3 router stores only R3A-owned revocable sessions. The R3A directory provider is read-only discovery and does not grant authority. CME's `r3a.capability-invocation.v1` path and configured authorization provider remain responsible for operation grants, denials, and capability audit. The AP3 session gateway does not create or modify grants. See the [authentication independence plan](R3A_AUTH_INDEPENDENCE_PLAN.md) for the bounded association and enrollment design and its approval gate.

## Contracts and flow

The target identity adapter is one replaceable `r3a.identity-provider.v1` implementation owned and operated by R3A. It must emit a verified canonical R3A principal assertion and must not create grants. The existing `HmacIngressIdentityProvider` and `R3AccountSessionIdentityProvider` are prior prototypes; in particular, the latter calls the live R3 account portal and is prohibited in independent R3A runtime configuration. Reuse of reviewed source does not permit runtime calls to R3. All accepted assertions enter the existing AP3 durable session store, principal contract, origin checks, generic CME invocation, and revocation flow.

On success, the portal creates a cryptographically random bearer token, stores only its SHA-256 digest plus principal/issuer/authentication-time/factor/expiry/revocation metadata in `r3a.steward_sessions`, and sets an HttpOnly, Secure (configurable for local testing), SameSite=Strict cookie. A unique assertion ID prevents replay. Logout revokes the durable session and expires the browser cookie. Session lookup reads the durable database each time, so revocation and unavailable state are visible immediately.

`GET /api/v1/steward/status` reads live CME health through its private control socket and records a correlated state-read event. If CME cannot be reached, health and freshness report `unavailable`; no configured endpoint is presented as live. `POST /api/v1/steward/operations/invoke` takes one canonical capability invocation. The portal overwrites caller principal with the authenticated session subject, clears resident/service self-claims, supplies a server correlation ID, and passes the request through the existing CME local control socket. CME evaluates the configured grant and operation/effect contract. The browser cannot make a caller-supplied grant authoritative. The CME authorization audit and portal correlation are returned with successful results; a denial remains a refusal and is audited.

Endpoints are opt-in via `R3A_STEWARD_ACCESS_CONFIG`; no auth route or listener is added by default. The configured `StewardAccess` instance is retained on `app.state.steward_access`; Website route adapters under `/api/v1/steward/` can use `Depends(require_steward_principal)` so desktop and mobile clients share the same cookie, durable session, and revocation authority. The generic `/operations/invoke` endpoint remains the capability gateway and CME remains the grant authority. The configuration requires a session DSN and explicitly records `public_exposure: false`. Remote transport status remains `unavailable` until a real encrypted ingress is provisioned. On 2026-11-08, AP0's isolated development database applied migration 009 and provisioned the dedicated least-privilege session role over a local peer-mapped socket. The active AP0 phase0 source directory still needs to incorporate migration 009 for future runner reconciliation. The Website router is now mounted on port 8311; no authenticated browser session has yet been established.

## Security and freshness

- No password database, duplicate resident roster, hardcoded grant, credential, or public endpoint is introduced.
- Secret values and raw assertions/tokens are not logged, returned, or stored; assertion IDs are only used for replay prevention.
- Authentication state, session lifecycle, operation outcome, and failure correlation are stored in PostgreSQL. CME remains authoritative for capability grant decisions.
- Invalid origin, invalid session, and operation denial paths append correlated denial events. A valid request with unavailable CME or session persistence reports unavailable instead of using cached state.
- Remote transport configuration requires `Secure` session cookies; same-origin and request-origin checks protect browser mutations.
- The `r3a_steward_access` database role has `USAGE` on schema `r3a`; `SELECT`, `INSERT`, and column-level `UPDATE(revoked_at)` on `r3a.steward_sessions`; and `INSERT` on `r3a.institution_events`. It has no role membership, schema/table ownership, event read/update/delete, session delete, or grant access. AP0's ordered migration runner applies schema changes as `r3a_runtime`; migration 009 follows 001–008 because it depends on the event ledger from 001. In the isolated development cluster, the OS `admin1` identity maps to this database role on a database-specific Unix-socket HBA rule.
- The session and operation endpoints fail closed on missing or stale identity, session, database, or CME state. They do not serve cached authentication or fabricate operation success.
- The R3 account-session endpoint is available locally at `127.0.0.1:8767`; an unauthenticated live request returns 401. The AP3 binding validates its existing cookie without acquiring another identity credential. The HMAC-ingress adapter remains available when a trusted ingress is deployed and uses Issue #50's versioned Bitwarden provider. The Website revision `ca07de47ddc1587471b81bffe3bd0b4b602ad2c8` integrates commit `12a30f9` and its Website-owned unit mounts the shared router using mode-0600 external development configuration. The endpoint returns 401 without a real portal login cookie; no authenticated session has been fabricated.
- `SecretProviderError.reason_code` is retained as a finite internal audit/status reason; the HTTP response remains generic and the exception message/CLI output is discarded. Provider outcomes such as credential unavailable, access denied, reference not found, and provider failure remain distinct internally.
- Development E2E sequence, after a Steward signs in through the existing portal: verify durable current AP3 session; submit a known authorized generic CME invocation and retain its activity/correlation/audit references; refresh the browser and verify continuity; revoke the AP3 session; repeat the invocation and verify denial plus durable denial audit; use an expired session and verify denial. Migration 009, the least-privilege role and grants, peer mapping, router mount, API failure-closed behavior, and portal's unauthenticated response have live evidence. The session table is empty; authenticated AP3 session behavior, authorized CME invocation, refresh continuity, revocation, and expiry have not been demonstrated live.
- TOTP and YubiKey have no current implementation; the assertion contract preserves issuer and authentication-factor provenance hooks for the next adapter revision.
