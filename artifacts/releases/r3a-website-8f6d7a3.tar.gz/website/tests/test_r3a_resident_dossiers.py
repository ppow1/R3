"""Tests for source-grounded resident dossier contracts and integration adapters."""

# R3 CONTROLLED SOURCE
# File: tests/test_r3a_resident_dossiers.py
# Component: R3A-RESIDENT-DOSSIERS-TESTS
# File Revision: 1.0.3
# Created: 2026-11-08 UTC (exact creation time not captured)
# Created By: Codex GPT-6
# Purpose: Cover roster data shape, prompt/config composition, privacy, governance, memory and epistemics.
# Execution Model: unittest; local fixtures and temporary directories only.
# Observability: Assertions report contract failures without connecting to production or external services.
# Dependencies: Python standard library; r3a_runtime.residents; data/residents.
# Authority: Steward directive; tests cannot certify live authoritative roster or operational readiness.
# Changed: 2026-11-08 UTC | CHARACTER-ARCHITECTURE | Codex GPT-6 | Add dossier architecture regressions.
# Changed: 2026-11-08 UTC | CA-03 | Codex GPT-6 | Assert authorization scope remains immutable within a context pin.
# Changed: 2026-11-08 UTC | CA-03 | Codex GPT-6 | Assert route and directory binding continuity on resumed boundaries.
# Changed: 2026-11-08 UTC | CA-05 | Codex GPT-6 | Assert tamper rejection and reference-only memory/communications projections.
# Supersedes: None
# Contracts: r3a.resident.dossier.v1; r3a.resident.prompt-composition.v1; memory/relationship/epistemic v1
# Tests: python3 -m unittest tests.test_r3a_resident_dossiers
# History/Predecessor: New file.

from __future__ import annotations

import json
import sqlite3
import shutil
import tempfile
import unittest
from pathlib import Path

from r3a_runtime.residents import (
    DossierRepository, DossierError, DossierValidationError, compose_prompt, resolve_personality,
    runtime_binding, validate_dossier, validate_emotional_state,
    validate_memory_entry, validate_relationship, append_memory_correction,
    evolve_relationship, transition_emotional_state,
    reconcile_records, InstitutionalIdentity, ProtectedRelationship, validate_steward_record,
    CharacterRevision, CharacterGovernance, transition_revision, RuntimePrincipal, load_runtime_context,
    validate_runtime_character_context,
    GovernedActor, GovernancePolicy, authorize_workflow_action,
    HRCapabilityIdentityResolver,
    R3CapabilityGrantAdapter, validate_identity_association,
    ApprovedCharacterContextProvider, project_context_for_sink,
    project_for_grace_context_v1, validate_approved_context, HRPrincipalAssociationAdapter,
)
from r3a_runtime.residents.validation import validate_epistemic_span
from r3a_runtime.residents.legacy_import import extract_legacy_hr_candidates
from r3a_runtime.capability_contracts import validate_schema_definition
from r3a_runtime.residents.coordinator_integration import (
    CoordinatorCharacterContextHook, CoordinatorExecutionBoundary,
    load_coordinator_package_manifest,
)


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data/residents"
DEFAULTS = json.loads((DATA / "global-config.v1.json").read_text())[
    "personality_defaults"
]


class ResidentDossierTests(unittest.TestCase):
    def setUp(self):
        self.repo = DossierRepository(DATA)

    def test_every_materialized_hr_identity_has_a_valid_unique_dossier(self):
        resident_ids = self.repo.list_ids()
        self.assertEqual(len(set(resident_ids)), len(resident_ids))
        self.assertIn("r3:evelyn", resident_ids)
        self.assertIn("r3:gm", resident_ids)
        self.assertNotIn("institution:steward", resident_ids)
        for resident_id in resident_ids:
            dossier = self.repo.get(resident_id)
            validate_dossier(dossier)
            self.assertEqual(dossier["identity"]["resident_id"], resident_id)
            self.assertEqual(dossier["governance"]["approval_status"], "in_review")
            self.assertEqual(dossier["character"]["bible_status"], "not_recovered")

    def test_new_governance_schemas_are_well_formed_json_and_versioned(self):
        expected = {
            "institutional-identity.v1.schema.json": "r3a.institutional.identity.v1",
            "protected-relationship.v1.schema.json": "r3a.resident.protected-relationship.v1",
            "runtime-character-context.v1.schema.json": "r3a.resident.runtime-character-context.v1",
            "resident-identity-association.v1.schema.json": "r3a.resident.identity-association.v1",
            "approved-character-context.v2.schema.json": "r3a.resident.approved-character-context.v2",
        }
        for filename, contract_id in expected.items():
            schema = json.loads((ROOT / "r3a_runtime/schemas" / filename).read_text())
            self.assertEqual(schema["$schema"], "https://json-schema.org/draft/2020-12/schema")
            self.assertEqual(schema["$id"], contract_id)
            if filename in {"resident-identity-association.v1.schema.json",
                            "approved-character-context.v2.schema.json"}:
                validate_schema_definition(schema)

    def test_coordinator_package_manifest_is_valid_and_keeps_context_out_of_cme_outputs(self):
        manifest = load_coordinator_package_manifest()
        self.assertEqual(manifest["integration_kind"], "coordinator-inference-context-hook")
        self.assertEqual(manifest["context_contract"]["version"], "2.0.0")
        self.assertEqual(manifest["sink_policy"]["generic_capability_output"],
                         "forbidden-for-character-text")
        self.assertIn("source-verified-hr-association", manifest["activation_gates"])
        with tempfile.TemporaryDirectory() as directory:
            invalid_manifest = Path(directory) / "package.json"
            invalid_manifest.write_text("{}", encoding="utf-8")
            with self.assertRaises(ValueError):
                load_coordinator_package_manifest(invalid_manifest)
            tampered = dict(manifest)
            tampered["artifacts"] = [dict(manifest["artifacts"][0], sha256="0" * 64)]
            invalid_manifest.write_text(json.dumps(tampered), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "artifact digest mismatch"):
                load_coordinator_package_manifest(invalid_manifest)

    def test_private_hr_office_and_protected_relationship_facts_are_not_in_git_dossiers(self):
        for resident_id in ("r3:evelyn", "r3:gm"):
            dossier = self.repo.get(resident_id)
            self.assertEqual(dossier["identity"]["display_name"], "Evelyn" if resident_id.endswith("evelyn") else "GM")
            self.assertIn("withheld", dossier["office"]["title"])
            self.assertEqual(dossier["relationships"], [])
            combined = json.dumps(dossier).casefold()
            self.assertNotIn("evelyn and gm", combined)
            self.assertNotIn("relationship milestone", combined)
            self.assertNotIn("onboarding", combined)

    def test_roster_index_is_data_driven_and_not_a_python_name_map(self):
        source = (ROOT / "r3a_runtime/residents/repository.py").read_text()
        for name in ("Grace", "Vicky", "Helen", "Jessica", "Chloe"):
            self.assertNotIn(f'"{name}"', source)
        self.assertEqual(self.repo.list_ids(), tuple(sorted(self.repo._index()["residents"])))

    def test_prompt_composition_is_stable_and_inspectable(self):
        dossier = self.repo.get("r3:grace")
        one = compose_prompt(dossier)
        two = compose_prompt(dossier)
        self.assertEqual(one, two)
        self.assertEqual(one.sha256, compose_prompt(dossier, provider_id="unmatched").sha256)
        self.assertTrue(one.component_refs)
        self.assertIn("VERIFIED", one.text)
        self.assertIn("no operational authority", one.text)

    def test_residents_are_differentiated_by_sourced_office_context(self):
        grace = compose_prompt(self.repo.get("r3:grace")).text
        vicky = compose_prompt(self.repo.get("r3:vicky")).text
        jessica = compose_prompt(self.repo.get("r3:jessica")).text
        self.assertIn("Director of Operations", grace)
        self.assertIn("Engineering Foundry", vicky)
        self.assertIn("Chief Character Architect", jessica)
        self.assertNotEqual(grace, vicky)

    def test_personality_override_precedence_and_validation(self):
        resident = {key: 40 for key in DEFAULTS}
        result, sources = resolve_personality(DEFAULTS, resident, [
            {"dimension": "warmth", "value": 80, "scope": "approved_experiment", "status": "approved"},
            {"dimension": "warmth", "value": 65, "scope": "resident", "scope_ref": "r3:grace", "status": "approved"},
            {"dimension": "humor", "value": 90, "scope": "approved_experiment", "status": "proposed"},
            {"dimension": "formality", "value": 70, "scope": "approved_experiment", "status": "approved"},
        ], resident_id="r3:grace")
        self.assertEqual(result["warmth"], 80)
        self.assertEqual(sources["warmth"], "approved_experiment")
        self.assertEqual(result["humor"], 40)
        self.assertEqual(result["formality"], 70)
        with self.assertRaises(DossierValidationError):
            resolve_personality(DEFAULTS, resident, [
                {"dimension": "warmth", "value": 200, "scope": "resident", "status": "approved"}
            ], resident_id="r3:grace")

    def test_repository_accepts_new_residents_without_runtime_roster_code_changes(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "residents"
            shutil.copytree(DATA, root)
            repo = DossierRepository(root)
            new_dossier = repo.get("r3:vicky")
            new_dossier["identity"]["resident_id"] = "resident:fixture-new"
            new_dossier["identity"]["display_name"] = "Fixture"
            new_dossier["identity"]["source_ids"] = []
            repo.create(new_dossier, actor="test", reason="exercise data-driven extensibility")
            self.assertIn("resident:fixture-new", repo.list_ids())
            self.assertEqual(repo.get("resident:fixture-new")["governance"]["approval_status"], "proposed")

    def test_provider_replacement_preserves_identity_and_continuity(self):
        dossier = self.repo.get("r3:grace")
        dossier["implementation"]["continuity_state_ref"] = "state://resident/r3:grace"
        local = runtime_binding(dossier, "local-provider-a", configuration_revision="config-a")
        cloud = runtime_binding(dossier, "chatgpt-provider-b", configuration_revision="config-b")
        self.assertEqual(local["resident_id"], cloud["resident_id"])
        self.assertEqual(local["continuity_state_ref"], cloud["continuity_state_ref"])
        self.assertNotEqual(local["provider_id"], cloud["provider_id"])
        self.assertEqual(cloud["capabilities"], [])
        self.assertIsNone(cloud["authority_ref"])

    def test_unconfirmed_directory_crosswalk_fails_closed(self):
        with self.assertRaises(KeyError):
            self.repo.resolve_source_id("r3a.execution-profile", "resident.grace")
        self.assertEqual(self.repo.resolve_source_id("r3a.execution-profile", "resident.grace",
                                                     confirmed_only=False), "r3:grace")

    def test_unverified_legacy_test_fixtures_are_not_treated_as_hr_crosswalk(self):
        for value in ("resident:Grace", "resident:Vicky", "resident:Helen",
                      "resident:Evelyn", "resident:GM"):
            with self.assertRaises(KeyError):
                self.repo.resolve_source_id("r3.legacy.hr-principal-map", value)

    def test_personnel_sensitive_and_protected_components_never_enter_prompt(self):
        dossier = self.repo.get("r3:grace")
        private = dict(dossier["prompt_components"][0])
        private.update({"component_id": "private-source", "version": "1.0.0",
                        "classification": "protected", "approval_status": "approved",
                        "text": "SHOULD NEVER APPEAR"})
        sensitive = dict(private)
        sensitive.update({"component_id": "sensitive-source", "classification": "personnel_sensitive",
                          "text": "ALSO PRIVATE"})
        dossier["prompt_components"].extend([private, sensitive])
        text = compose_prompt(dossier).text
        self.assertNotIn("SHOULD NEVER APPEAR", text)
        self.assertNotIn("ALSO PRIVATE", text)

    def test_epistemic_spans_require_provenance_for_verified_and_canon(self):
        base = {"span_id": "span-1", "start": 0, "end": 31,
                "text": "Grace is Director of Operations.", "sources": [],
                "classified_by": "test-fixture", "classified_at": "2026-11-08T00:00:00Z",
                "audit_status": "pending"}
        with self.assertRaises(DossierValidationError):
            validate_epistemic_span({**base, "classification": "VERIFIED"})
        with self.assertRaises(DossierValidationError):
            validate_epistemic_span({**base, "classification": "CANON"})
        validate_epistemic_span({**base, "classification": "UNKNOWN"})
        validate_epistemic_span({**base, "classification": "CANON", "sources": [
            {"source_id": "charter", "locator": "section 2"}
        ]})

    def test_memory_relationship_and_emotion_are_separate_provenance_contracts(self):
        memory = {"memory_id": "m1", "category": "episodic", "content_ref": "mem://1",
                               "source_refs": ["conversation://1"], "occurred_at": "2026-11-08T00:00:00Z",
                               "recorded_at": "2026-11-08T00:01:00Z", "classification": "institutional",
                               "retention_rule_ref": "policy://memory/default", "status": "active"}
        validate_memory_entry(memory)
        correction = append_memory_correction(memory, {"memory_id": "m2", "category": "episodic",
            "content_ref": "mem://2", "source_refs": ["correction://1"],
            "occurred_at": "2026-11-08T00:00:00Z", "recorded_at": "2026-11-08T00:02:00Z",
            "classification": "institutional", "retention_rule_ref": "policy://memory/default",
            "status": "corrected"})
        self.assertEqual(correction["supersedes_memory_id"], "m1")
        self.assertEqual(memory["memory_id"], "m1")
        relationship = {"relationship_id": "r1", "from_resident_id": "r3:grace",
                               "to_resident_id": "r3:vicky", "affinity": 0.1, "trust": 50,
                               "respect": 70, "professional_rapport": 60,
                               "basis_refs": ["experience://shared-work"], "history": []}
        validate_relationship(relationship)
        grown = evolve_relationship(relationship, affinity=0.2, trust=55, respect=70,
                                    professional_rapport=65, experience_ref="experience://delivery",
                                    occurred_at="2026-11-08T01:00:00Z")
        self.assertEqual(grown["history"][0]["trust"], 50)
        self.assertEqual(grown["trust"], 55)
        initial_emotion = {"state_id": "e1", "resident_id": "r3:grace",
                                  "captured_at": "2026-11-08T00:00:00Z", "expires_at": None,
                                  "source_ref": "interaction://1", "values": {"dominant_emotion": "calm", "intensity": 40}}
        validate_emotional_state(initial_emotion)
        next_emotion = transition_emotional_state(initial_emotion, {"state_id": "e2", "resident_id": "r3:grace",
            "captured_at": "2026-11-08T00:02:00Z", "expires_at": None,
            "source_ref": "interaction://2", "values": {"dominant_emotion": "amused", "intensity": 45}})
        self.assertEqual(next_emotion["supersedes_state_id"], "e1")
        with self.assertRaises(ValueError):
            validate_relationship({"relationship_id": "r2", "from_resident_id": "r3:grace",
                                  "to_resident_id": "r3:vicky", "affinity": 0.1, "trust": 50,
                                  "respect": 70, "professional_rapport": 60, "basis_refs": [], "history": []})

    def test_hr_and_character_approval_ownership_and_rollback(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "residents"
            shutil.copytree(DATA, root)
            repo = DossierRepository(root)
            repo.set_approval("r3:grace", "1.0.1", expected_revision="1.0.0",
                              actor="principal:character-architect", owner="character_architecture", approved=True,
                              reason="decision claim recorded; repository is not the authenticating authority")
            character_approved = repo.get("r3:grace")
            self.assertEqual(character_approved["governance"]["approval_status"], "in_review")
            self.assertNotIn("hr", character_approved["governance"]["owner_approvals"])
            repo.set_approval("r3:grace", "1.0.2", expected_revision="1.0.1",
                              actor="Helen", owner="hr", approved=True,
                              reason="personnel review recorded")
            self.assertEqual(repo.get("r3:grace")["governance"]["approval_status"], "in_review")
            repo.rollback("r3:grace", to_revision="1.0.0", expected_revision="1.0.2",
                          actor="Steward", reason="restore prior approved source")
            self.assertEqual(repo.get("r3:grace")["revision"], "1.0.0")
            audit = (root / "audit.jsonl").read_text()
            self.assertIn("revision_added", audit)

    def test_reconciliation_fails_closed_and_distinguishes_projection_conditions(self):
        unavailable = {"source": {"availability": "unavailable", "freshness": "unavailable",
                                   "error": "directory_source_not_configured"}, "residents": []}
        self.assertEqual(reconcile_records(unavailable, ["r3:grace"], [],)[0].state,
                         "authoritative_source_unavailable")
        measured_empty = {"source": {"availability": "measured", "freshness": "fresh"}, "residents": []}
        self.assertEqual(reconcile_records(measured_empty, [], [], hr_access_state="insufficient")[0].state,
                         "hr_access_insufficient")
        self.assertEqual(reconcile_records(measured_empty, [], [], synchronization_state="failed")[0].state,
                         "directory_synchronization_unhealthy")
        snapshot = {"source": {"availability": "measured", "freshness": "fresh"},
                    "residents": [{"resident_id": "directory:grace"}]}
        unresolved = reconcile_records(snapshot, ["r3:grace"], ["r3:grace"])
        self.assertEqual({item.state for item in unresolved}, {
            "hr_identity_crosswalk_missing", "directory_identity_crosswalk_missing"})
        same_spelling = {"source": {"availability": "measured", "freshness": "fresh"},
                         "residents": [{"resident_id": "r3:grace"}]}
        same_id_unresolved = reconcile_records(same_spelling, ["r3:grace"], ["r3:grace"])
        self.assertEqual({item.state for item in same_id_unresolved}, {
            "hr_identity_crosswalk_missing", "directory_identity_crosswalk_missing"})
        result = reconcile_records(snapshot, ["r3:grace"], [],
                                   confirmed_crosswalk={"directory:grace": "r3:grace"})
        self.assertEqual([(item.institutional_id, item.state) for item in result],
                         [("r3:grace", "dossier_missing")])
        result2 = reconcile_records(snapshot, ["r3:grace"], ["r3:grace"],
                                    confirmed_crosswalk={"directory:grace": "r3:grace"})
        self.assertEqual(result2[0].state, "resident_credential_missing_or_unverified")
        result3 = reconcile_records(snapshot, ["r3:grace"], ["r3:grace"],
                                    confirmed_crosswalk={"directory:grace": "r3:grace"},
                                    credential_ids=["r3:grace"])
        self.assertEqual(result3[0].state, "matched_observed_records")
        duplicates = {"source": {"availability": "measured", "freshness": "fresh"},
                      "residents": [{"resident_id": "x"}, {"resident_id": "x"}]}
        self.assertEqual(reconcile_records(duplicates, ["x"], ["x"],
                                           confirmed_crosswalk={"x": "x"})[0].state,
                         "directory_binding_ambiguous")
        truncated = {"source": {"availability": "measured", "freshness": "fresh",
                                "potentially_truncated": True}, "residents": []}
        self.assertEqual(reconcile_records(truncated, ["r3:grace"], ["r3:grace"],
                                           confirmed_crosswalk={"directory:grace": "r3:grace"})[0].state,
                         "directory_projection_incomplete")
        crosswalk_conflict = reconcile_records(snapshot, ["r3:grace", "r3:other"], [],
            confirmed_crosswalk={"directory:grace": "r3:grace", "directory:other": "r3:grace"})
        self.assertEqual(crosswalk_conflict[0].state, "identity_crosswalk_conflict")

    def test_steward_classification_excludes_resident_lifecycle(self):
        identity = InstitutionalIdentity("configured-authority-id", "Steward", "STEWARD", "governance://steward")
        self.assertEqual(identity.classification, "STEWARD")
        valid = {"classification": "STEWARD", "institutional_id": identity.institutional_id,
                 "authority_ref": identity.authority_ref, "identity_write_policy": "steward_governed_only",
                 "preferences_ref": "governance://steward/preferences"}
        validate_steward_record(valid)
        with self.assertRaises(ValueError):
            validate_steward_record({**valid, "employment_status": "active"})
        resident = InstitutionalIdentity("resident:id", "Resident", "RESIDENT", "hr://resident")
        self.assertEqual(resident.classification, "RESIDENT")
        with self.assertRaises(ValueError):
            validate_steward_record({**valid, "classification": "RESIDENT"})

    def test_protected_relationship_acl_is_separate_from_directory_discovery(self):
        relation = ProtectedRelationship(
            "relationship://protected/record", ("r3:evelyn", "r3:gm"), "protected",
            frozenset({"principal:steward-fixture", "principal:hr-fixture", "principal:character-fixture"}),
            frozenset({"principal:steward-fixture", "principal:hr-fixture"}),
            ("steward.character-architecture-directive",), "1.0.0",
            {"character_development": ("approved_interaction_context",)}, ())
        with self.assertRaises(PermissionError):
            relation.project("principal:resident-fixture", purpose="character_development")
        self.assertEqual(relation.project("principal:character-fixture", purpose="character_development")["facts"], [])
        with self.assertRaises(PermissionError):
            relation.require_edit("principal:character-fixture")
        relation.require_edit("principal:hr-fixture")

    def test_character_revision_requires_configured_independent_self_review_and_activation(self):
        policy = CharacterGovernance(frozenset({"reviewer-7"}), "governance://reviewer-policy",
                                     frozenset({"reviewer-7", "character-editor"}),
                                     frozenset({"character-editor"}), frozenset({"runtime-operator"}))
        own = CharacterRevision("r3:jessica", "1.0.1", "jessica", "in_review",
                                ("source://evidence",), True, True)
        with self.assertRaises(PermissionError):
            transition_revision(own, target_state="approved", actor_id="jessica", governance=policy)
        with self.assertRaises(PermissionError):
            transition_revision(own, target_state="approved", actor_id="character-editor", governance=policy)
        approved = transition_revision(own, target_state="approved", actor_id="reviewer-7", governance=policy)
        published = transition_revision(approved, target_state="published", actor_id="character-editor", governance=policy)
        active = transition_revision(published, target_state="active", actor_id="runtime-operator", governance=policy)
        self.assertEqual(active.status, "active")
        with self.assertRaises(ValueError):
            transition_revision(own, target_state="active", actor_id="runtime-operator", governance=policy)

    def test_hr_character_and_steward_ownership_uses_configured_attested_principals(self):
        policy = GovernancePolicy(
            frozenset({"principal:hr"}), frozenset({"principal:character"}),
            frozenset({"principal:reviewer"}), frozenset({"principal:publisher"}),
            frozenset({"principal:runtime"}), frozenset({"principal:steward"}),
            frozenset({"principal:character"}), frozenset({"principal:hr", "principal:character"}),
            "governance://policy/revision-4")
        authorize_workflow_action(GovernedActor("principal:hr", "auth-ref:hr"), policy, "hr.office.assign")
        authorize_workflow_action(GovernedActor("principal:character", "auth-ref:char"), policy,
                                  "character.propose")
        authorize_workflow_action(GovernedActor("principal:character", "auth-ref:char"), policy,
                                  "character.interaction_context.read", target_classification="STEWARD")
        with self.assertRaises(PermissionError):
            authorize_workflow_action(GovernedActor("principal:character", "auth-ref:char"), policy,
                                      "hr.office.assign")
        with self.assertRaises(PermissionError):
            authorize_workflow_action(GovernedActor("principal:character", "auth-ref:char"), policy,
                                      "character.approve", revision_author_id="principal:character",
                                      durable_canon_change=True)
        authorize_workflow_action(GovernedActor("principal:reviewer", "auth-ref:review"), policy,
                                  "character.approve", revision_author_id="principal:character",
                                  durable_canon_change=True)
        self_review_policy = GovernancePolicy(
            policy.hr_managers, policy.character_architects,
            frozenset({"principal:character"}), policy.character_publishers,
            policy.runtime_activators, policy.stewards, policy.steward_context_readers,
            policy.dossier_readers, policy.policy_ref)
        with self.assertRaises(PermissionError):
            authorize_workflow_action(GovernedActor("principal:character", "auth-ref:char"),
                                      self_review_policy, "character.approve",
                                      revision_author_id="principal:character",
                                      durable_canon_change=True)
        with self.assertRaises(PermissionError):
            authorize_workflow_action(GovernedActor("principal:character", "auth-ref:char"), policy,
                                      "character.propose", target_classification="STEWARD")
        with self.assertRaises(PermissionError):
            authorize_workflow_action(GovernedActor("principal:character", "auth-ref:char"), policy,
                                      "steward.identity.update", target_classification="STEWARD")

    def test_existing_hr_capability_is_used_for_canonical_identity_resolution(self):
        from types import SimpleNamespace

        class HRCapabilityStub:
            def __init__(self):
                self.calls = []
            def read(self, principal, resident_id):
                self.calls.append((principal.principal_id, resident_id))
                if resident_id == "r3:missing":
                    return None
                return {"resident_id": resident_id, "revision": 4, "status": "onboarding"}

        hr = HRCapabilityStub()
        resolver = HRCapabilityIdentityResolver(
            hr, resolve_verified_principal=lambda actor: SimpleNamespace(
                principal_id="principal:verified", role="character_architect"))
        actor = GovernedActor("principal:jessica", "auth-ref:authenticated-session")
        identity = resolver(actor, "r3:vicky")
        self.assertEqual(identity, {
            "institutional_id": "r3:vicky", "status": "authoritative",
            "classification": "RESIDENT", "revision": 4,
            "source_ref": "hr://record/r3:vicky@4",
        })
        self.assertEqual(hr.calls, [("principal:verified", "r3:vicky")])
        self.assertEqual(resolver(actor, "r3:missing")["status"], "missing")

    def test_r3_exact_grant_adapter_verifies_actor_and_records_auditable_decisions(self):
        from types import SimpleNamespace

        class R3AuthorityStub:
            def __init__(self):
                self.checks = []
                self.audits = []
            def authorize(self, **request):
                self.checks.append(request)
                if request["scope_ref"] == "r3:denied":
                    raise PermissionError("no exact grant")
                return {"grant_id": "grant:test:1"}
            def audit(self, event):
                self.audits.append(event)

        authority = R3AuthorityStub()
        adapter = R3CapabilityGrantAdapter(
            authority,
            resolve_verified_principal=lambda actor: (
                SimpleNamespace(principal_id=actor.principal_id, role="steward")
                if actor.authentication_ref == "server-session:valid" else None),
        )
        valid = GovernedActor("human:steward:test", "server-session:valid")
        forged = GovernedActor("human:steward:test", "client-supplied-session")
        self.assertTrue(adapter.verify_actor(valid))
        self.assertFalse(adapter.verify_actor(forged))
        self.assertTrue(adapter.authorize_character(valid, "character.propose", "r3:vicky"))
        self.assertFalse(adapter.authorize_character(valid, "character.propose", "r3:denied"))
        self.assertTrue(adapter.authorize_hr(
            SimpleNamespace(principal_id="human:steward:test", role="steward"),
            "hr.read", "r3:vicky"))
        self.assertTrue(adapter.authorize_hr(
            SimpleNamespace(principal_id="human:helen:test", role="helen"),
            "hr.write", "r3:vicky"))
        self.assertEqual(authority.checks[0], {
            "principal": "human:steward:test", "resource_id": "r3:character-dossiers",
            "action": "character.propose", "operation": "write", "scope_ref": "r3:vicky",
        })
        self.assertEqual(authority.checks[3], {
            "principal": "human:helen:test", "resource_id": "r3:hr",
            "action": "hr.write", "operation": "write", "scope_ref": "r3:vicky",
        })
        self.assertEqual([entry["outcome"] for entry in authority.audits],
                         ["allowed", "denied", "allowed", "allowed"])
        self.assertTrue(all(entry["correlation_id"] and entry["scope_ref"]
                            for entry in authority.audits))

    def test_identity_association_requires_independent_source_references_and_matching_binding(self):
        association = {
            "schema_id": "r3a.resident.identity-association", "schema_version": 1,
            "association_ref": "association://r3:grace/revision/1", "resident_id": "r3:grace",
            "hr": {"resident_id": "r3:grace", "revision": 3,
                   "source_ref": "hr://record/r3:grace@3",
                   "authority_principal": "resident:grace",
                   "principal_association_ref": "hr://association/r3:grace@3"},
            "dossier": {"resident_id": "r3:grace", "revision": "1.0.1", "status": "active"},
            "directory": {"source_id": "riverview_authority.directory",
                          "source_contract": "riverview-authority.directory.v1",
                          "snapshot_sha256": "a" * 64, "observed_at": "2026-11-08T14:01:26Z",
                          "principal_id": "resident:grace", "office_id": "office:grace",
                          "office_role": "Director of Operations", "binding_revision": 9},
            "credential_ref": "credential://resident:grace/credential-id",
            "grant_refs": ["grant://character/read/1", "grant://character/activate/1"],
            "runtime": {"profile_id": "resident.grace", "profile_revision": "1.2.9",
                        "route_id": "objective_reasoning"},
            "evidence_refs": ["source://hr", "source://directory", "source://credential", "source://runtime"],
            "verified_at": "2026-11-08T14:02:00Z",
        }
        self.assertIs(validate_identity_association(association), association)
        with self.assertRaises(ValueError):
            validate_identity_association({**association, "directory": {
                **association["directory"], "principal_id": "resident:someone-else"}})
        with self.assertRaises(ValueError):
            validate_identity_association({**association, "credential_ref": "credential://?token=secret"})

    def test_runtime_context_resolves_hr_identity_before_applying_prompt(self):
        dossier = self.repo.get("r3:grace")
        dossier["governance"]["approval_status"] = "active"
        identity = {"institutional_id": "r3:grace", "status": "authoritative", "revision": 7}
        context = load_runtime_context(institutional_id="r3:grace",
            principal=RuntimePrincipal("resident.grace", "conversation", frozenset({"public", "institutional"}), "hr-authz:1"),
            resolve_identity=lambda value: {**identity, "directory_resident_id": "resident.grace"}, load_dossier=lambda value: dossier,
            defaults=DEFAULTS, overrides=[], provider_id="provider:test")
        self.assertEqual(context["resident_id"], "r3:grace")
        self.assertEqual(context["dossier_revision"], "1.0.0")
        self.assertFalse(context["authority_granted"])
        validated = validate_runtime_character_context(context, directory_resident_id="resident.grace")
        self.assertEqual(validated["classification_scope"], ["institutional", "public"])
        with self.assertRaises(PermissionError):
            load_runtime_context(institutional_id="missing", principal=RuntimePrincipal("p", "conversation", frozenset(), "hr-authz:2"),
                resolve_identity=lambda value: {"status": "unavailable"}, load_dossier=lambda value: dossier,
                defaults=DEFAULTS, overrides=[], provider_id="provider:test")

    def test_approved_context_is_pinned_to_boundary_and_filtered_per_sink(self):
        import copy

        dossier = copy.deepcopy(self.repo.get("r3:grace"))
        dossier["governance"]["approval_status"] = "active"

        class RepositoryStub:
            def __init__(self):
                self.pin = None
            def get_context_pin(self, **kwargs):
                return self.pin
            def get(self, resident_id, revision=None):
                self.assert_identity(resident_id)
                return copy.deepcopy(dossier)
            def revision_digest(self, resident_id, revision):
                return "a" * 64
            def has_activation(self, resident_id, revision):
                return True
            def pin_context(self, **kwargs):
                self.pin = {"pin_id": "context-pin:1", "resident_id": kwargs["resident_id"],
                            "dossier_revision": kwargs["revision"],
                            "dossier_sha256": kwargs["dossier_sha256"],
                            "identity_revision": kwargs["identity_revision"],
                            "directory_resident_id": kwargs["directory_resident_id"],
                            "binding_revision": kwargs["binding_revision"],
                            "directory_snapshot_sha256": kwargs["directory_snapshot_sha256"],
                            "directory_source_ref": kwargs["directory_source_ref"],
                            "hr_source_ref": kwargs["hr_source_ref"],
                            "hr_principal_association_ref": kwargs["hr_principal_association_ref"],
                            "office_id": kwargs["office_id"], "office_role": kwargs["office_role"],
                            "execution_profile_id": kwargs["execution_profile_id"],
                            "execution_profile_revision": kwargs["execution_profile_revision"],
                            "execution_profile_resident_id": kwargs["execution_profile_resident_id"],
                            "execution_route_id": kwargs["execution_route_id"],
                            "execution_profile_source_ref": kwargs["execution_profile_source_ref"],
                            "authorized_classifications": list(kwargs["authorized_classifications"]),
                            "provider_id": kwargs["provider_id"],
                            "principal_ref": kwargs["principal_ref"],
                            "execution_kind": kwargs["execution_kind"],
                            "execution_ref": kwargs["execution_ref"]}
                return self.pin
            @staticmethod
            def assert_identity(resident_id):
                if resident_id != "r3:grace":
                    raise KeyError(resident_id)

        repository = RepositoryStub()
        actor = GovernedActor("resident:grace", "r3-session:authenticated")
        authorization_scope = {"value": {"public"}}
        identity_projection = {
            "institutional_id": "r3:grace", "status": "authoritative",
            "classification": "RESIDENT", "revision": 4,
            "directory_resident_id": "resident:grace", "binding_revision": 9,
            "authority_principal": "resident:grace",
            "principal_association_ref": "hr://association/r3:grace@4",
            "source_ref": "hr://record/r3:grace@4",
            "directory_source_ref": "directory://snapshot/" + "c" * 64,
            "directory_snapshot_sha256": "c" * 64,
            "directory_snapshot_fresh": True,
            "office_id": "office:grace", "office_role": "Director of Operations",
            "execution_profile_id": "profile:grace",
            "execution_profile_revision": "1.2.9",
            "execution_profile_resident_id": "resident:grace",
            "execution_route_id": "route:grace-primary",
            "execution_profile_source_ref": "profile://grace@1.2.9",
        }
        provider = ApprovedCharacterContextProvider(
            repository,
            resolve_hr_identity=lambda actor, resident_id: {
                **identity_projection, "institutional_id": resident_id},
            authorize_context=lambda actor, action, scope: (
                authorization_scope["value"] if action == "character.context.read" and scope == "r3:grace"
                else False),
            defaults=DEFAULTS,
        )
        context = provider.retrieve(actor, resident_id="r3:grace",
            execution_kind="conversation_boundary", execution_ref="conversation:turn:1",
            provider_id="model:grace")
        # Coordinator acceptance: inject only authenticated boundary facts, then
        # assert each sink receives its allowed projection (never generic CME output).
        sink_audits = []
        hook = CoordinatorCharacterContextHook(
            provider, authorize_sink=lambda boundary, sink, resident_id: {"public"},
            audit=sink_audits.append)
        boundary = CoordinatorExecutionBoundary(
            actor=actor, resident_id="r3:grace", execution_kind="conversation_boundary",
            execution_ref="conversation:turn:hook-test", provider_id="model:grace",
            sink_principal_ref="coordinator:inference:authenticated",
        )
        inference_projection = hook.project(boundary, sink="inference")
        self.assertIn("prompt_text", inference_projection)
        memory_projection = hook.project(boundary, sink="memory")
        communications_projection = hook.project(boundary, sink="communications")
        diagnostics_projection = hook.project(boundary, sink="diagnostics")
        for projection in (memory_projection, communications_projection, diagnostics_projection):
            self.assertNotIn("prompt_text", projection)
        denied_hook = CoordinatorCharacterContextHook(
            provider, authorize_sink=lambda boundary, sink, resident_id: set(),
            audit=sink_audits.append)
        with self.assertRaises(PermissionError):
            denied_hook.project(boundary, sink="inference")
        self.assertEqual([entry["outcome"] for entry in sink_audits],
                         ["allowed"] * 4 + ["denied"])
        self.assertNotIn("prompt_text", json.dumps(sink_audits))
        with self.assertRaises(TypeError):
            CoordinatorExecutionBoundary(
                actor={"principal_id": "user-controlled"}, resident_id="r3:grace",
                execution_kind="conversation_boundary", execution_ref="request:ref",
                provider_id="model:grace", sink_principal_ref="coordinator:inference")
        self.assertEqual(context["contract_version"], "2.0.0")
        self.assertEqual(context["pin_ref"], "context-pin:1")
        self.assertEqual(context["classification_scope"], ["public"])
        self.assertEqual(context["office_id"], "office:grace")
        self.assertIs(validate_approved_context(context)["authority_granted"], False)
        altered_prompt = copy.deepcopy(context)
        altered_prompt["prompt_text"] += " changed"
        with self.assertRaisesRegex(ValueError, "prompt digest mismatch"):
            validate_approved_context(altered_prompt)
        protected_scope = copy.deepcopy(context)
        protected_scope["classification_scope"] = ["protected"]
        with self.assertRaisesRegex(PermissionError, "protected classifications"):
            validate_approved_context(protected_scope)
        grace_context = project_for_grace_context_v1(context, verified_execution_profile={
            "profile_id": "profile:grace", "profile_revision": "1.2.9",
            "resident_id": "resident:grace", "route_id": "route:grace-primary",
            "source_ref": "profile://grace@1.2.9",
        })
        self.assertEqual(grace_context["contract_version"], "1.0.0")
        self.assertEqual(set(grace_context), {
            "contract_id", "contract_version", "resident_id", "directory_resident_id",
            "identity_binding_status", "identity_revision", "dossier_revision", "approval_status",
            "classification_scope", "authorization_ref", "prompt_text", "prompt_sha256",
            "prompt_component_refs", "source_refs", "personality", "personality_sources",
            "provider_id", "authority_granted",
        })
        self.assertIn("context-pin:1", grace_context["source_refs"])
        self.assertIn("character-context-sha256:" + context["context_sha256"],
                      grace_context["source_refs"])
        with self.assertRaises(PermissionError):
            project_for_grace_context_v1(context, verified_execution_profile={
                "profile_id": "profile:grace", "profile_revision": "1.2.9",
                "resident_id": "resident.grace", "route_id": "route:grace-primary",
                "source_ref": "profile://grace@1.2.9",
            })
        resumed = provider.retrieve(actor, resident_id="r3:grace",
            execution_kind="conversation_boundary", execution_ref="conversation:turn:1",
            provider_id="model:grace")
        self.assertEqual(resumed["pin_ref"], context["pin_ref"])
        self.assertEqual(resumed["context_sha256"], context["context_sha256"])
        identity_projection["execution_route_id"] = "route:grace-changed"
        with self.assertRaisesRegex(PermissionError, "pinned character context"):
            provider.retrieve(actor, resident_id="r3:grace",
                execution_kind="conversation_boundary", execution_ref="conversation:turn:1",
                provider_id="model:grace")
        identity_projection["execution_route_id"] = "route:grace-primary"
        identity_projection["binding_revision"] = 10
        with self.assertRaisesRegex(PermissionError, "pinned character context"):
            provider.retrieve(actor, resident_id="r3:grace",
                execution_kind="conversation_boundary", execution_ref="conversation:turn:1",
                provider_id="model:grace")
        identity_projection["binding_revision"] = 9
        authorization_scope["value"] = {"public", "institutional"}
        with self.assertRaisesRegex(PermissionError, "pinned character context"):
            provider.retrieve(actor, resident_id="r3:grace",
                execution_kind="conversation_boundary", execution_ref="conversation:turn:1",
                provider_id="model:grace")
        authorization_scope["value"] = {"public"}
        for field, changed_value in (
            ("revision", 5),
            ("directory_snapshot_sha256", "d" * 64),
            ("office_id", "office:changed"),
            ("execution_profile_revision", "1.2.10"),
            ("execution_profile_source_ref", "profile://grace@1.2.10"),
            ("source_ref", "hr://record/r3:grace@5"),
        ):
            original_value = identity_projection[field]
            identity_projection[field] = changed_value
            with self.assertRaisesRegex(PermissionError, "pinned character context"):
                provider.retrieve(actor, resident_id="r3:grace",
                    execution_kind="conversation_boundary", execution_ref="conversation:turn:1",
                    provider_id="model:grace")
            identity_projection[field] = original_value
        with self.assertRaisesRegex(PermissionError, "pinned character context"):
            provider.retrieve(actor, resident_id="r3:grace",
                execution_kind="conversation_boundary", execution_ref="conversation:turn:1",
                provider_id="model:grace-replacement")
        events = []
        memory = project_context_for_sink(context, sink="memory",
            authorized_classifications=frozenset({"public", "institutional"}),
            principal_ref="memory:authorized", audit=events.append)
        self.assertTrue(memory["context_reference_only"])
        self.assertNotIn("prompt_text", memory)
        communications = project_context_for_sink(context, sink="communications",
            authorized_classifications=frozenset({"public", "institutional"}),
            principal_ref="communications:authorized", audit=events.append)
        self.assertTrue(communications["context_reference_only"])
        self.assertNotIn("prompt_text", communications)
        diagnostics = project_context_for_sink(context, sink="diagnostics",
            authorized_classifications=frozenset({"public", "institutional"}),
            principal_ref="diagnostics:authorized", audit=events.append)
        self.assertNotIn("prompt_text", diagnostics)
        with self.assertRaises(PermissionError):
            project_context_for_sink(context, sink="inference",
                authorized_classifications=frozenset(), principal_ref="inference:denied",
                audit=events.append)
        self.assertEqual([event["outcome"] for event in events],
                         ["allowed", "allowed", "allowed", "denied"])
        self.assertEqual(set(events[-1]), {
            "principal_ref", "sink", "pin_ref", "context_sha256", "outcome"})
        self.assertNotIn("prompt_text", json.dumps(events))

    def test_hr_association_adapter_fails_closed_without_hr_provenance_operation(self):
        from types import SimpleNamespace

        class Authority:
            def __init__(self):
                self.audits = []
            def authorize(self, **kwargs):
                return {"grant_id": "grant:hr-write"}
            def audit(self, event):
                self.audits.append(event)

        class HR:
            def read(self, principal, resident_id):
                return {"resident_id": resident_id, "revision": 4}
            def associate_authority_principal(self, *args, **kwargs):
                raise AssertionError("non-provenance mutation must never be called")

        authority = Authority()
        grants = R3CapabilityGrantAdapter(authority,
            resolve_verified_principal=lambda actor: SimpleNamespace(
                principal_id=actor.principal_id, role="helen"))
        adapter = HRPrincipalAssociationAdapter(HR(), grants,
            resolve_directory_evidence=lambda actor, evidence_ref: evidence)
        evidence = {
            "source_id": "riverview_authority.directory",
            "source_contract": "riverview-authority.directory.v1",
            "snapshot_sha256": "b" * 64,
            "observed_at": "2026-11-08T14:01:26Z",
            "principal_id": "resident:vicky",
            "office_id": "office:engineering",
            "office_role": "Engineering Manager",
            "binding_revision": 2,
            "evidence_refs": ["directory-snapshot://sha256/" + "b" * 64],
            "verified_at": "2026-11-08T14:02:00Z",
        }
        with self.assertRaisesRegex(NotImplementedError, "lacks associate_authority_principal_with_provenance"):
            adapter.associate(GovernedActor("human:helen", "session:server-verified"),
                resident_id="r3:vicky", authority_principal="resident:vicky",
                expected_hr_revision=4, evidence_ref=evidence["evidence_refs"][0])
        self.assertEqual(authority.audits[-1]["outcome"], "allowed")
        self.assertEqual(authority.audits[-1]["action"], "hr.write")

    def test_vicky_minimum_configuration_is_available_without_fabricated_biography(self):
        vicky = self.repo.get("r3:vicky")
        prompt = compose_prompt(vicky).text
        self.assertIn("Engineering Foundry", prompt)
        self.assertEqual(vicky["character"]["backstory"]["status"], "not_recovered")
        self.assertTrue(vicky["open_questions"])
        self.assertEqual(vicky["relationships"], [])

    def test_grace_casual_social_exchange_is_not_forced_into_work_tracking(self):
        prompt = compose_prompt(self.repo.get("r3:grace")).text
        self.assertIn("may remain social", prompt)
        self.assertIn("do not redirect an invitation to coffee", prompt)

    def test_legacy_hr_import_is_explicit_allowlist_read_only_and_omits_classified_fields(self):
        with tempfile.TemporaryDirectory() as temp:
            db = Path(temp) / "hr.sqlite3"
            connection = sqlite3.connect(db)
            connection.execute("CREATE TABLE hr_records (resident_id TEXT PRIMARY KEY, revision INTEGER, payload TEXT)")
            connection.execute("INSERT INTO hr_records VALUES (?, ?, ?)", (
                "r3:sample", 7, json.dumps({"display_name": "Sample", "office": "Office",
                                            "status": "onboarding", "fields": {
                                                "private": {"value": "never-export", "classification": "confidential"}}})
            ))
            connection.commit()
            connection.close()
            candidates = extract_legacy_hr_candidates(db, ["r3:sample"])
            self.assertEqual(len(candidates), 1)
            self.assertEqual(candidates[0]["approval_status"], "proposed")
            self.assertTrue(candidates[0]["sensitive_fields_present"])
            self.assertNotIn("office", candidates[0])
            self.assertNotIn("lifecycle_status", candidates[0])
            self.assertNotIn("never-export", json.dumps(candidates))
            with self.assertRaises(ValueError):
                extract_legacy_hr_candidates(db, [])
            with self.assertRaises(KeyError):
                extract_legacy_hr_candidates(db, ["r3:absent"])
            reopened = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
            self.assertEqual(reopened.execute("SELECT revision FROM hr_records").fetchone()[0], 7)
            reopened.close()


if __name__ == "__main__":
    unittest.main()
