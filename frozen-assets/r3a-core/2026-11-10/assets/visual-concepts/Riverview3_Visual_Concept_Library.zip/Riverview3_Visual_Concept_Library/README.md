# Riverview 3 — Visual Concept Library

This library preserves the available original reference images and samples of their interface designs for later comparison.

- `backgrounds/R3_modern_dashboard_as_is.png`: preserved preferred modern UI concept, unchanged.
- `backgrounds/R3_modern_estate_clean_concept.png`: newly generated clean companion concept. It is a re-creation, not a pixel-perfect removal of overlays.
- `originals/`: complete available images, including the four-panel comparison and earlier Estate references.
- `overlay_references/`: cropped examples of menus, status flags, resident cards, CME diagrams, resource panels, and location labels.

**Important:** The generated images are flattened raster images. Crops preserve appearance for design selection but are not clean transparent layers, CSS, or functional controls. The final site overlays must be rebuilt as independently positioned, live-data-driven UI elements.

**Design requirements:** CME belongs to Riverview, not Grace; resident identity cards appear on hover/tap; panels can collapse, expand, and drill down; retain a subtle Undercurrent visual easter egg; five P100 GPUs in planned inventory, with live counts verified separately; preserve all-women residents except Alfred and the Gray Man. All displayed status values in concept art are illustrative.
